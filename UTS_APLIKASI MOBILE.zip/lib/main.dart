import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Toko Buah Lia',
      theme: ThemeData(
        primarySwatch: Colors.green,
        textTheme: TextTheme(
          headline1: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
          bodyText1: TextStyle(fontSize: 16.0),
        ),
      ),
      home: HomePage(),
      routes: {
        '/login': (context) => LoginPage(),
        '/register': (context) => RegisterPage(),
        '/fruitStore': (context) => FruitStorePage(),
        '/search': (context) => SearchPage(),
      },
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Toko Buah Lia'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Image.network(
                'https://tse1.mm.bing.net/th?id=OIP.MozRjq35RlvNVz-IO1XTdwAAAA&pid=Api&P=0&h=180',
                height: 150,
              ),
              SizedBox(height: 20),
              Text(
                'Selamat Datang di Toko Buah Lia',
                style: Theme.of(context).textTheme.headline1,
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/login');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange, // Ganti warna tombol Login
                ),
                child: Text('Login'),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/register');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue, // Ganti warna tombol Daftar
                ),
                child: Text('Daftar'),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavBar(),
    );
  }
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              decoration: InputDecoration(
                hintText: 'Email',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Password',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Aksi setelah login berhasil
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => FruitStorePage()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange, // Ganti warna tombol Login
              ),
              child: Text('Login'),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavBar(),
    );
  }
}

class RegisterPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daftar'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              decoration: InputDecoration(
                hintText: 'Nama Lengkap',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              decoration: InputDecoration(
                hintText: 'Email',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Password',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Aksi setelah registrasi berhasil
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => FruitStorePage()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue, // Ganti warna tombol Daftar
              ),
              child: Text('Daftar'),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavBar(),
    );
  }
}

class FruitStorePage extends StatefulWidget {
  @override
  _FruitStorePageState createState() => _FruitStorePageState();
}

class _FruitStorePageState extends State<FruitStorePage> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Toko Buah Segar'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            // Fitur Pencarian
            TextField(
              decoration: InputDecoration(
                hintText: 'Cari Buah Segar...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SearchPage()),
                );
              },
            ),
            SizedBox(height: 20),
            Text(
              'Rekomendasi Buah',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                Column(
                  children: [
                    Image.network(
                      'http://2.bp.blogspot.com/-g1xsF4-Uz-o/UdDve-JmsVI/AAAAAAAACV8/zmtFNXRfxbQ/s1600/download+gambar+buah+jeruk.jpg',
                      width: 50,
                      height: 50,
                    ),
                    Text('Jeruk'),
                  ],
                ),
                Column(
                  children: [
                    Image.network(
                      'https://images.wisegeek.com/strawberries.jpg',
                      width: 50,
                      height: 50,
                    ),
                    Text('Strawberry'),
                  ],
                ),
                Column(
                  children: [
                    Image.network(
                      'https://tse3.mm.bing.net/th?id=OIP.LZC8nEegarcUWUztBIf3BgHaE8&pid=Api&P=0&h=180',
                      width: 50,
                      height: 50,
                    ),
                    Text('Semangka'),
                  ],
                ),
                Column(
                  children: [
                    Image.network(
                      'https://tse1.mm.bing.net/th?id=OIP.x0qZw2SWIORems_L9PnfdQHaGL&pid=Api&P=0&h=180',
                      width: 50,
                      height: 50,
                    ),
                    Text('Mangga'),
                  ],
                ),
              ],
            ),
            SizedBox(height: 20),
            Text(
              'Daftar Buah',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            ListTile(
              leading: Image.network(
                'http://2.bp.blogspot.com/-g1xsF4-Uz-o/UdDve-JmsVI/AAAAAAAACV8/zmtFNXRfxbQ/s1600/download+gambar+buah+jeruk.jpg',
                width: 50,
                height: 50,
              ),
              title: Text('Jeruk Sunkist'),
              subtitle: Text('Rp 20.000/kg'),
              trailing: Icon(Icons.shopping_cart),
            ),
            ListTile(
              leading: Image.network(
                'https://manfaat.co.id/wp-content/uploads/2014/08/buah-semangka-300x220.jpg',
                width: 50,
                height: 50,
              ),
              title: Text('Semangka Segar'),
              subtitle: Text('Rp 15.000/kg'),
              trailing: Icon(Icons.shopping_cart),
            ),
            ListTile(
              leading: Image.network(
                'https://images.wisegeek.com/strawberries.jpg',
                width: 50,
                height: 50,
              ),
              title: Text('Strawberry Manis'),
              subtitle: Text('Rp 30.000/kg'),
              trailing: Icon(Icons.shopping_cart),
            ),
            ListTile(
              leading: Image.network(
                'https://tse1.mm.bing.net/th?id=OIP.x0qZw2SWIORems_L9PnfdQHaGL&pid=Api&P=0&h=180',
                width: 50,
                height: 50,
              ),
              title: Text('Mangga Madu'),
              subtitle: Text('Rp 25.000/kg'),
              trailing: Icon(Icons.shopping_cart),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavBar(),
    );
  }
}

class SearchPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Hasil Pencarian'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            // Contoh hasil pencarian untuk beberapa buah
            FruitItem(
              imageUrl:
                  'http://2.bp.blogspot.com/-g1xsF4-Uz-o/UdDve-JmsVI/AAAAAAAACV8/zmtFNXRfxbQ/s1600/download+gambar+buah+jeruk.jpg',
              name: 'Jeruk Sunkist',
              price: 'Rp 20.000/kg',
            ),
            FruitItem(
              imageUrl:
                  'https://manfaat.co.id/wp-content/uploads/2014/08/buah-semangka-300x220.jpg',
              name: 'Semangka Segar',
              price: 'Rp 15.000/kg',
            ),
            FruitItem(
              imageUrl: 'https://images.wisegeek.com/strawberries.jpg',
              name: 'Strawberry Manis',
              price: 'Rp 30.000/kg',
            ),
            FruitItem(
              imageUrl:
                  'https://tse1.mm.bing.net/th?id=OIP.x0qZw2SWIORems_L9PnfdQHaGL&pid=Api&P=0&h=180',
              name: 'Mangga Madu',
              price: 'Rp 25.000/kg',
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavBar(),
    );
  }
}

class FruitItem extends StatelessWidget {
  final String imageUrl;
  final String name;
  final String price;

  const FruitItem({
    Key? key,
    required this.imageUrl,
    required this.name,
    required this.price,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: ListTile(
        leading: Image.network(
          imageUrl,
          width: 50,
          height: 50,
          fit: BoxFit.cover,
        ),
        title: Text(name),
        subtitle: Text(price),
        trailing: Icon(Icons.shopping_cart),
      ),
    );
  }
}

class BottomNavBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      items: const <BottomNavigationBarItem>[
        BottomNavigationBarItem(
          icon: Icon(Icons.home),
          label: 'Beranda',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.shopping_cart),
          label: 'Keranjang',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person),
          label: 'Akun',
        ),
      ],
      currentIndex: 0,
      onTap: (index) {
        // Navigasi ke halaman yang sesuai
        switch (index) {
          case 0:
            Navigator.pushReplacement(
                context, MaterialPageRoute(builder: (context) => HomePage()));
            break;
          case 1:
            // Navigasi ke halaman keranjang
            break;
          case 2:
            // Navigasi ke halaman akun
            break;
        }
      },
    );
  }
}
